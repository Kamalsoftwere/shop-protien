import ProductCard from "./ProductCard";
import proteinClear from "@/assets/protein-clear.jpg";
import creatineImpact from "@/assets/creatine-impact.jpg";
import wheyIsolate from "@/assets/whey-isolate.jpg";
import dietWhey from "@/assets/diet-whey.jpg";

const products = [
  {
    id: "clear-whey-protein",
    image: proteinClear,
    name: "Clear Whey Protein Powder",
    rating: 4.5,
    reviewCount: 6089,
    price: "174.22 ₪",
  },
  {
    id: "impact-creatine",
    image: creatineImpact,
    name: "Impact Creatine",
    rating: 4.5,
    reviewCount: 4312,
    price: "32.85 ₪",
  },
  {
    id: "whey-isolate",
    image: wheyIsolate,
    name: "Impact Whey Isolate Powder",
    rating: 4.5,
    reviewCount: 3971,
    price: "153.00 ₪",
  },
  {
    id: "diet-whey",
    image: dietWhey,
    name: "Impact Diet Whey",
    rating: 4.5,
    reviewCount: 2546,
    price: "187.68 ₪",
  },
];

const BestSellers = () => {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">
          Best Sellers
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <ProductCard key={index} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestSellers;