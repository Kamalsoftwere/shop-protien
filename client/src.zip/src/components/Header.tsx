import { Search, User, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Header = () => {
  return (
    <header className="bg-background border-b border-border sticky top-0 z-50">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground py-2">
        <div className="container mx-auto px-4 text-center text-sm">
          Free shipping on orders over $50 | Premium supplements for your health journey
        </div>
      </div>
      
      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-hero rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">KD</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary">KAMAL DALLASHEH</h1>
              <p className="text-xs text-muted-foreground">Premium Supplements</p>
            </div>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input 
                placeholder="Search for products..." 
                className="pl-10 bg-muted/50 border-border focus:ring-accent"
              />
            </div>
          </div>

          {/* User Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="hover:bg-accent hover:text-accent-foreground">
              <User className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-accent hover:text-accent-foreground relative">
              <ShoppingCart className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 bg-accent text-accent-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
                0
              </span>
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center space-x-8 py-3">
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Protein
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Nutrition
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Activewear
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Vitamins
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Bars, Drinks & Snacks
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Vegan
            </Button>
            <Button variant="ghost" className="text-primary-foreground hover:bg-primary-hover">
              Performance
            </Button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;