import { Star, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

interface ProductCardProps {
  id: string;
  image: string;
  name: string;
  rating: number;
  reviewCount: number;
  price: string;
  originalPrice?: string;
}

const ProductCard = ({ id, image, name, rating, reviewCount, price, originalPrice }: ProductCardProps) => {
  const navigate = useNavigate();
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) ? "fill-accent text-accent" : "text-muted-foreground"
        }`}
      />
    ));
  };

  return (
    <Card 
      className="group cursor-pointer transition-all duration-300 hover:shadow-product bg-gradient-card border-border/50"
      onClick={() => navigate(`/product/${id}`)}
    >
      <CardContent className="p-4">
        <div className="aspect-square mb-4 bg-white rounded-lg p-4 flex items-center justify-center overflow-hidden">
          <img 
            src={image} 
            alt={name}
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        
        <h3 className="font-semibold text-lg mb-2 text-card-foreground group-hover:text-primary transition-colors">
          {name}
        </h3>
        
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center">
            {renderStars(rating)}
          </div>
          <span className="text-sm text-muted-foreground">({reviewCount})</span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-primary">{price}</span>
            {originalPrice && (
              <span className="text-lg text-muted-foreground line-through">{originalPrice}</span>
            )}
          </div>
          
          <Button 
            size="sm" 
            className="bg-accent hover:bg-accent-hover text-accent-foreground"
          >
            <ShoppingCart className="w-4 h-4 mr-1" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;