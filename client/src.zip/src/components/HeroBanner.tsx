import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-banner.jpg";

const HeroBanner = () => {
  return (
    <section 
      className="relative h-96 bg-cover bg-center flex items-center justify-center"
      style={{ backgroundImage: `url(${heroImage})` }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-accent/60"></div>
      <div className="relative z-10 text-center text-white max-w-2xl px-4">
        <h2 className="text-5xl font-bold mb-4">
          NEW YEAR <span className="text-accent">DROP</span>
        </h2>
        <p className="text-xl mb-6 opacity-90">
          Transform your fitness journey with premium supplements
        </p>
        <Button 
          size="lg" 
          className="bg-accent hover:bg-accent-hover text-accent-foreground px-8 py-3 text-lg font-semibold"
        >
          SHOP NOW
        </Button>
      </div>
    </section>
  );
};

export default HeroBanner;