import { Button } from "@/components/ui/button";

const categories = [
  { name: "PROTEIN", color: "bg-primary" },
  { name: "CREATINE", color: "bg-primary" },
  { name: "ACTIVEWEAR", color: "bg-primary" },
  { name: "BARS\nFOODS\n& Snacks", color: "bg-primary" },
  { name: "VEGAN", color: "bg-primary" },
  { name: "BUNDLES\n& Boxes", color: "bg-primary" },
];

const CategoryCards = () => {
  return (
    <section className="py-12 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category, index) => (
            <Button
              key={index}
              variant="outline"
              className={`${category.color} text-primary-foreground hover:bg-primary-hover h-24 text-sm font-bold whitespace-pre-line border-0 shadow-card`}
            >
              {category.name}
            </Button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryCards;