import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Star, ShoppingCart, Heart, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/Header";

// Product data (in a real app, this would come from an API or database)
const productData = {
  "clear-whey-protein": {
    id: "clear-whey-protein",
    name: "Clear Whey Protein Powder",
    image: "/client/src/assets/protein-clear.jpg",
    rating: 4.5,
    reviewCount: 6089,
    price: "174.22 ₪",
    originalPrice: "199.99 ₪",
    description: "Our Clear Whey Protein is a premium, refreshing protein drink that provides 20g of high-quality protein per serving. Unlike traditional protein shakes, this clear formula mixes easily with water to create a light, refreshing drink.",
    features: [
      "20g of high-quality whey protein per serving",
      "Light and refreshing - not thick or milky",
      "Available in delicious fruity flavors",
      "Fast absorption for optimal muscle recovery",
      "Low in sugar and fat"
    ],
    nutritionFacts: {
      servingSize: "25g",
      calories: "90",
      protein: "20g",
      carbohydrates: "1g",
      fat: "0.1g",
      sugar: "0.5g"
    },
    ingredients: "Whey Protein Isolate (Milk), Natural Flavoring, Citric Acid, Sucralose, Natural Colors"
  },
  "impact-creatine": {
    id: "impact-creatine",
    name: "Impact Creatine",
    image: "/client/src/assets/creatine-impact.jpg",
    rating: 4.5,
    reviewCount: 4312,
    price: "32.85 ₪",
    description: "Pure Creatine Monohydrate to help increase physical performance in successive bursts of short-term, high intensity exercise.",
    features: [
      "3g of pure creatine monohydrate per serving",
      "Supports explosive power and strength",
      "Enhances muscle energy production",
      "Unflavored - mixes easily with any drink",
      "Pharmaceutical grade quality"
    ],
    nutritionFacts: {
      servingSize: "3g",
      calories: "0",
      protein: "0g",
      carbohydrates: "0g",
      fat: "0g",
      creatine: "3g"
    },
    ingredients: "100% Creatine Monohydrate"
  },
  "whey-isolate": {
    id: "whey-isolate",
    name: "Impact Whey Isolate Powder",
    image: "/client/src/assets/whey-isolate.jpg",
    rating: 4.5,
    reviewCount: 3971,
    price: "153.00 ₪",
    description: "Our premium Whey Protein Isolate provides 25g of high-quality protein with minimal lactose, making it perfect for those with dairy sensitivities.",
    features: [
      "25g of premium whey protein isolate per serving",
      "90% protein content - highest quality",
      "Low in lactose, fat, and carbs",
      "Fast-absorbing for post-workout recovery",
      "Available in multiple delicious flavors"
    ],
    nutritionFacts: {
      servingSize: "30g",
      calories: "110",
      protein: "25g",
      carbohydrates: "1g",
      fat: "0.5g",
      sugar: "0.5g"
    },
    ingredients: "Whey Protein Isolate (Milk), Natural and Artificial Flavoring, Lecithin, Sucralose"
  },
  "diet-whey": {
    id: "diet-whey",
    name: "Impact Diet Whey",
    image: "/client/src/assets/diet-whey.jpg",
    rating: 4.5,
    reviewCount: 2546,
    price: "187.68 ₪",
    description: "Our Diet Whey blend combines high-quality protein with added ingredients to support your weight management goals.",
    features: [
      "22g of protein per serving",
      "Added L-Carnitine and Green Tea Extract",
      "Lower calorie formula",
      "Supports lean muscle maintenance",
      "Great taste with added nutritional benefits"
    ],
    nutritionFacts: {
      servingSize: "35g",
      calories: "95",
      protein: "22g",
      carbohydrates: "2g",
      fat: "1g",
      sugar: "1g"
    },
    ingredients: "Whey Protein Concentrate (Milk), L-Carnitine, Green Tea Extract, Natural Flavoring, Sucralose"
  }
};

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const product = id ? productData[id as keyof typeof productData] : null;

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold text-primary mb-4">Product Not Found</h1>
          <Button onClick={() => navigate('/')}>Return to Home</Button>
        </div>
      </div>
    );
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < Math.floor(rating) ? "fill-accent text-accent" : "text-muted-foreground"
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Back Button */}
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="mb-6 hover:bg-muted"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Products
        </Button>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <Card className="bg-white p-8 flex items-center justify-center min-h-[500px]">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-contain max-w-md"
              />
            </Card>
          </div>

          {/* Product Information */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-primary mb-4">{product.name}</h1>
              
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center">
                  {renderStars(product.rating)}
                </div>
                <span className="text-muted-foreground">
                  {product.rating} ({product.reviewCount} reviews)
                </span>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <span className="text-4xl font-bold text-primary">{product.price}</span>
                {product.originalPrice && (
                  <span className="text-xl text-muted-foreground line-through">
                    {product.originalPrice}
                  </span>
                )}
              </div>
            </div>

            <p className="text-lg text-muted-foreground leading-relaxed">
              {product.description}
            </p>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button 
                size="lg" 
                className="flex-1 bg-accent hover:bg-accent-hover text-accent-foreground"
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Add to Cart
              </Button>
              <Button variant="outline" size="lg">
                <Heart className="w-5 h-5" />
              </Button>
              <Button variant="outline" size="lg">
                <Share2 className="w-5 h-5" />
              </Button>
            </div>

            {/* Product Details Tabs */}
            <Tabs defaultValue="features" className="mt-8">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="features">Features</TabsTrigger>
                <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
                <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
              </TabsList>
              
              <TabsContent value="features" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4 text-primary">Key Features</h3>
                    <ul className="space-y-2">
                      {product.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="w-2 h-2 bg-accent rounded-full mt-2 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="nutrition" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4 text-primary">Nutrition Facts</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(product.nutritionFacts).map(([key, value]) => (
                        <div key={key} className="flex justify-between border-b border-border pb-2">
                          <span className="capitalize font-medium">
                            {key.replace(/([A-Z])/g, ' $1').trim()}:
                          </span>
                          <span className="font-semibold">{value}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="ingredients" className="mt-6">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4 text-primary">Ingredients</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {product.ingredients}
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;